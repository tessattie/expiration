<!DOCTYPE html>
<html>
<head>
	<title>CARIBBEAN</title>
	<meta charset="UTF-8">
	<link rel="stylesheet" href="/expiration/public/bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" href="/expiration/public/bootstrap/css/bootstrap.css">
	<link rel="stylesheet" href="//cdn.datatables.net/1.10.12/css/jquery.dataTables.min.css">
	<link rel="stylesheet" href="/expiration/public/bootstrap/css/bootstrap-theme.css">
	<link rel="stylesheet" href="/expiration/public/bootstrap/css/bootstrap-theme.min.css">
	<link rel="stylesheet" href="/expiration/public/css/style.css">
	<link rel="stylesheet" href="/expiration/public/css/BootSideMenu.css">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<style type="text/css">
        .user {
            padding: 5px;
            margin-bottom: 5px;
            text-align: center;
        }
    </style>
</head>
<body>
<div class="container-fluid">