</div>
<!--/Test -->

<!-- Beggining of script declaration -->
<script type="text/javascript" src="/expiration/public/js/jquery-1.11.3.min.js"></script> 
<script type="text/javascript" src="/expiration/public/bootstrap/js/bootstrap.js"></script> 
<script type="text/javascript" src="/expiration/public/bootstrap/js/bootstrap.min.js"></script>
<script src="/expiration/public/js/BootSideMenu.js"></script>
<script type="text/javascript" src="/expiration/public/js/script.js"></script>
<script type="text/javascript" src="/expiration/public/js/dataTables/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="/expiration/public/js/dataTables.js"></script>


<!-- End of script declaration -->
</body>
</html>