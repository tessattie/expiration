<?php include_once '/../header.php'; ?>

<?php include_once '/../menu.php'; ?>

<h4 class="errorpagemessage">Sorry, this page does not exist !</h4>

<?php include_once '/../footer.php'; ?>